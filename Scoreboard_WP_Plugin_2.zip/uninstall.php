<?php
/**
 * Created by PhpStorm.
 * User: NaraJeamfry
 * Date: 21/08/2017
 * Time: 3:38
 */

if (!defined('WP_UNINSTALL_PLUGIN')) {
	die;
}

